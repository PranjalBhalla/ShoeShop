package com.example.shoeapp


import android.graphics.Color

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shoeapp.Extensions.toast
import com.example.shoeapp.Models.CartModel
import com.example.shoeapp.R
import com.example.shoeapp.databinding.FragmentCartpageBinding

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

class CartFragment : Fragment(R.layout.fragment_cartpage), CartAdapter.OnLongClickRemove, CartAdapter.CartItemChangeListener {

    private lateinit var binding: FragmentCartpageBinding
    private lateinit var cartList: ArrayList<CartModel>
    private lateinit var auth: FirebaseAuth
    private lateinit var adapter: CartAdapter
    private var subTotalPrice = 0

    private var orderDatabaseReference = Firebase.firestore.collection("orders")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentCartpageBinding.bind(view)
        auth = FirebaseAuth.getInstance()

        binding.cartActualToolbar.setNavigationOnClickListener {
            Navigation.findNavController(requireView()).popBackStack()
        }

        val layoutManager = LinearLayoutManager(context)

        cartList = ArrayList()

        retrieveCartItems()

        adapter = CartAdapter(requireContext(), cartList, this, this)
        binding.rvCartItems.adapter = adapter
        binding.rvCartItems.layoutManager = layoutManager

        binding.btnCartCheckout.setOnClickListener {
            requireActivity().toast("Whooooa!! You've Ordered Products worth $subTotalPrice\nYour Product will be delivered in the next 7 days")
            cartList.clear()
            subTotalPrice = 0
            binding.tvLastSubTotalprice.text = "0"
            binding.tvLastTotalPrice.text = "Min 1 product is Required"
            binding.tvLastTotalPrice.setTextColor(Color.RED)
            adapter.notifyDataSetChanged()
        }
    }

    private fun retrieveCartItems() {
        orderDatabaseReference
            .whereEqualTo("uid", auth.currentUser!!.uid)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (item in querySnapshot) {
                    val cartProduct = item.toObject<CartModel>()
                    cartList.add(cartProduct)
                    subTotalPrice += cartProduct.price!!.toInt()
                    binding.tvLastSubTotalprice.text = subTotalPrice.toString()
                    binding.tvLastTotalPrice.text = subTotalPrice.toString()
                    adapter.notifyDataSetChanged()
                }
            }
            .addOnFailureListener {
                requireActivity().toast(it.localizedMessage!!)
            }
    }

    override fun onLongRemove(item: CartModel, position: Int) {
        orderDatabaseReference
            .whereEqualTo("uid", item.uid)
            .whereEqualTo("pid", item.pid)
            .whereEqualTo("size", item.size)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (item in querySnapshot) {
                    val cartProduct = item.toObject<CartModel>()
                    orderDatabaseReference.document(item.id).delete()
                    subTotalPrice -= cartProduct.price!!.toInt()
                    cartList.removeAt(position)
                    binding.tvLastSubTotalprice.text = subTotalPrice.toString()
                    binding.tvLastTotalPrice.text = subTotalPrice.toString()
                    adapter.notifyItemRemoved(position)
                    requireActivity().toast("Removed Successfully!!!")
                }
            }
            .addOnFailureListener {
                requireActivity().toast("Failed to remove")
            }
    }

    override fun onQuantityChange(item: CartModel, newQuantity: Int) {
        // Log the changes
        Log.d("CartFragment", "Item: ${item.name}, New Quantity: $newQuantity")

        // Update the subtotal price in real-time when quantities change
        subTotalPrice += (newQuantity - item.quantity!!) * item.price!!.toInt()

        // Update the quantity in the item
        item.quantity = newQuantity

        // Update the UI elements
        binding.tvLastSubTotalprice.text = subTotalPrice.toString()
        binding.tvLastTotalPrice.text = subTotalPrice.toString()

        // Notify the adapter that the data has changed
        adapter.notifyDataSetChanged()
    }

}
